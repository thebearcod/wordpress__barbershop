<picture>
  <source media="(min-width: 1200px)" srcset="<?php echo get_template_directory_uri(); ?>/assets/img/logotype-desktop.svg">
  <source media="(min-width: 768px)" srcset="<?php echo get_template_directory_uri(); ?>/assets/img/logotype-tablet.svg">
  <img src="<?php echo get_template_directory_uri(); ?>/assets/img/logotype-mobile.svg" width="370" height="153" alt="Барбершоп «Бородинский»">
</picture>